# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import snowflake.connector
import os

# Thông tin kết nối Snowflake
conn_params = {
    'user': 'dohung24112002',
    'password': 'Doviethung24112002@',
    'account': 'uz36730.ap-southeast-1',
    'warehouse': 'COMPUTE_WH',
    'database': 'AIRBNB',
    'schema': 'DEV'
}

# Tạo kết nối tới Snowflake
conn = snowflake.connector.connect(**conn_params)
print('Connected Successfully!')

# Read recipe inputs
Target_Dataset = dataiku.Dataset("TARGET_DATASET")
Target_Dataset_df = Target_Dataset.get_dataframe()


# Bảng đích trong Snowflake
target_table = 'DWH_CHURN_DATASET'

# Đọc dữ liệu hiện có trong Snowflake 
existing_data_query = f"SELECT * FROM {target_table}"
existing_data_df = pd.read_sql(existing_data_query, conn)
print(f"Existing data rows: {len(existing_data_df)}")

# Đổi tên cột 'CUSTOMERID' thành 'customerID' trong existing_data_df
existing_data_df = existing_data_df.rename(columns={'CUSTOMERID': 'customerID'})

# print(existing_data_df.columns)
# print(Target_Dataset_df.columns)


# Xác định các bản ghi cần cập nhật hoặc thêm mới
merged_df = pd.merge(Target_Dataset_df, existing_data_df, on='customerID', how='outer', indicator=True)
to_update_df = merged_df[merged_df['_merge'] == 'both']
to_insert_df = merged_df[merged_df['_merge'] == 'left_only']

### UPDATE STEP ###
# Xác định các bản ghi cần cập nhật thực sự (các cột khác nhau)
cols_to_compare = [col.replace('_x', '') for col in to_update_df.columns if col.endswith('_x')]

for col in cols_to_compare:
    to_update_df[col + '_different'] = to_update_df[col + '_x'] != to_update_df[col + '_y']

# Lọc các bản ghi có ít nhất một cột khác nhau
to_update_df = to_update_df[to_update_df[[col + '_different' for col in cols_to_compare]].any(axis=1)]

# Loại bỏ các cột so sánh
to_update_df.drop(columns=[col + '_different' for col in cols_to_compare], inplace=True)

# ----------# 

print(f"Records to update: {len(to_update_df)}, Records to insert: {len(to_insert_df)}")

# Lọc các cột có hậu tố `_x`
to_update_df = to_update_df.filter(regex='_x$|customerID')
to_insert_df = to_insert_df.filter(regex='_x$|customerID')

# Đổi tên các cột để loại bỏ hậu tố `_x`
to_update_df.columns = [col.rstrip('_x') for col in to_update_df.columns]
to_insert_df.columns = [col.rstrip('_x') for col in to_insert_df.columns]


### INSERT STEP ###
# Đường dẫn tệp CSV trên máy cục bộ
local_file_path = '/home/dataiku/dss/python_file/to_insert_df.csv'

# Lấy thư mục từ đường dẫn tệp
directory = os.path.dirname(local_file_path)

# Kiểm tra xem thư mục có tồn tại hay không, nếu không thì tạo mới
if not os.path.exists(directory):
    os.makedirs(directory)
    
# Lưu DataFrame đã chuẩn hóa thành tệp CSV
to_insert_df.to_csv(local_file_path, index=False)


### INCREMENTAL UPDATE STEPS ###
# Thực hiện cập nhật các bản ghi
if not to_update_df.empty:
    update_query = """
    UPDATE {table}
    SET {set_clause}
    WHERE CUSTOMERID = %s
    """
    for _, row in to_update_df.iterrows():
        set_clause = ', '.join([f"{col} = %s" for col in row.index if col != 'customerID'])
        values = [row[col] for col in row.index if col != 'customerID'] + [row['customerID']]
        conn.cursor().execute(update_query.format(table=target_table, set_clause=set_clause), values)

# Thực hiện chèn các bản ghi mới

# Tên stage và tệp trên Snowflake
stage_name = 'my_stage'
stage_file_path = f'@{stage_name}/to_insert_df.csv'

# Tạo stage nếu chưa tồn tại
conn.cursor().execute(f"CREATE OR REPLACE STAGE {stage_name}")

# Tải tệp CSV lên Snowflake Stage
conn.cursor().execute(f"PUT file://{local_file_path} {stage_file_path}")

# Chèn dữ liệu từ stage vào bảng
copy_query = f"""
COPY INTO {target_table}
FROM {stage_file_path}
FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY = '"' SKIP_HEADER = 1)
"""
conn.cursor().execute(copy_query)


# Đóng kết nối
conn.close()

