# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import os

# Read recipe inputs
UNUSAL_TRANSACTIONS = dataiku.Dataset("UNUSAL_TRANSACTIONS")
UNUSAL_TRANSACTIONS_df = UNUSAL_TRANSACTIONS.get_dataframe()


# Compute recipe outputs from inputs
# TODO: Replace this part by your actual code that computes the output, as a Pandas dataframe
# NB: DSS also supports other kinds of APIs for reading and writing data. Please see doc.

Send_Email_df = UNUSAL_TRANSACTIONS_df # For this sample code, simply copy input to output

if not Send_Email_df.empty:
    # Write recipe outputs
    Send_Email = dataiku.Dataset("SEND_EMAIL")
    Send_Email.write_with_schema(Send_Email_df)

    # Lưu DataFrame thành file CSV
    csv_file_path = "/home/dataiku/dss/python_file/UNUSAL_TRANSACTIONS.csv"

    # Lấy thư mục từ đường dẫn tệp
    directory = os.path.dirname(csv_file_path)

    # Kiểm tra xem thư mục có tồn tại hay không, nếu không thì tạo mới
    if not os.path.exists(directory):
        os.makedirs(directory)


    Send_Email_df.to_csv(csv_file_path, index=False)

    # Thông tin đăng nhập và cài đặt email
    gmail_user = 'd5485235741569@gmail.com'
    gmail_password = 'wmjm ieat wlav bnss'
    to_email = 'dohung24112002@gmail.com'
    subject = 'Unusal Transactions'
    body = 'See Attachments: '

    # Tạo đối tượng MIMEMultipart
    msg = MIMEMultipart()
    msg['From'] = gmail_user
    msg['To'] = to_email
    msg['Subject'] = subject

    # Tạo nội dung email
    body_text = MIMEText(body, 'plain')
    msg.attach(body_text)

    # Đính kèm file CSV vào email
    with open(csv_file_path, "rb") as file:
        part = MIMEApplication(file.read(), Name=os.path.basename(csv_file_path))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(csv_file_path)}"'
        msg.attach(part)

    # Kết nối đến máy chủ SMTP của Gmail và gửi email
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Nâng cấp kết nối lên an toàn
        server.login(gmail_user, gmail_password)  # Đăng nhập
        text = msg.as_string()
        server.sendmail(gmail_user, to_email, text)  # Gửi email
        server.quit()  # Ngắt kết nối

        print('Email đã được gửi thành công!')
    except Exception as e:
        print(f'Xảy ra lỗi: {e}')
